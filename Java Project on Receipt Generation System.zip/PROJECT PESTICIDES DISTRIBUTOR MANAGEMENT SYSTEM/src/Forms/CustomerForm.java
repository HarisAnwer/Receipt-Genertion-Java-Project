
package Forms;
import Classes.DatabaseConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import Classes.CustomerInfo;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomerForm extends javax.swing.JFrame
{
    Connection con = new DatabaseConnection().setConnection();

    public CustomerForm() 
    {
        initComponents();
        new CustomerInfo().Refresh(emp_jTable);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        emp_jTable = new javax.swing.JTable();
        title_jLabel = new javax.swing.JLabel();
        Add_jButton = new javax.swing.JButton();
        delete_jButton = new javax.swing.JButton();
        update_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        refresh_jButton = new javax.swing.JButton();
        search_lbl = new javax.swing.JLabel();
        search_jTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Id_jTextField = new javax.swing.JTextField();
        name_lbl = new javax.swing.JLabel();
        cnic_lbl = new javax.swing.JLabel();
        contact_lbl = new javax.swing.JLabel();
        address_lbl = new javax.swing.JLabel();
        email_lbl = new javax.swing.JLabel();
        faxno_lbl = new javax.swing.JLabel();
        name_jTextField = new javax.swing.JTextField();
        address_jTextField = new javax.swing.JTextField();
        email_jTextField = new javax.swing.JTextField();
        faxno_jTextField = new javax.swing.JTextField();
        company_lbl = new javax.swing.JLabel();
        product_lbl = new javax.swing.JLabel();
        quantity_jTextField = new javax.swing.JTextField();
        quantity_lbl = new javax.swing.JLabel();
        priceperitem_lbl = new javax.swing.JLabel();
        priceperitem_jTextField = new javax.swing.JTextField();
        totalamount_lbl = new javax.swing.JLabel();
        totalamount_jTextField = new javax.swing.JTextField();
        cnic_jFormattedTextField = new javax.swing.JFormattedTextField();
        contact_jTextField = new javax.swing.JTextField();
        loyality_jButton = new javax.swing.JButton();
        PDF = new javax.swing.JButton();
        comapny_jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        product_jComboBox1 = new javax.swing.JComboBox<>();
        jTextField2 = new javax.swing.JTextField();
        empback_jLabel = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        emp_jMenu = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Customer Form");
        setBounds(new java.awt.Rectangle(924, 557, 557, 557));
        setMinimumSize(new java.awt.Dimension(924, 557));
        setResizable(false);
        setSize(new java.awt.Dimension(924, 557));
        getContentPane().setLayout(null);

        emp_jTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        emp_jTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emp_jTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(emp_jTable);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 370, 922, 180);

        title_jLabel.setFont(new java.awt.Font("Algerian", 0, 36)); // NOI18N
        title_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        title_jLabel.setText("CUSTOMER INFORMATION");
        getContentPane().add(title_jLabel);
        title_jLabel.setBounds(200, 10, 420, 60);

        Add_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(null);
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(700, 300, 100, 25);

        delete_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        delete_jButton.setText("DELETE");
        delete_jButton.setBorder(null);
        delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(delete_jButton);
        delete_jButton.setBounds(700, 330, 100, 25);

        update_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        update_jButton.setText("UPDATE");
        update_jButton.setBorder(null);
        update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(update_jButton);
        update_jButton.setBounds(810, 300, 100, 25);

        clear_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(null);
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(590, 330, 100, 25);

        refresh_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        refresh_jButton.setText("REFRESH");
        refresh_jButton.setBorder(null);
        refresh_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refresh_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(refresh_jButton);
        refresh_jButton.setBounds(810, 330, 100, 25);

        search_lbl.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        search_lbl.setForeground(new java.awt.Color(255, 255, 255));
        search_lbl.setText("SEARCH");
        search_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(search_lbl);
        search_lbl.setBounds(679, 25, 59, 25);

        search_jTextField.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        search_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_jTextFieldActionPerformed(evt);
            }
        });
        search_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(search_jTextField);
        search_jTextField.setBounds(742, 25, 155, 25);

        jLabel2.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(jLabel2);
        jLabel2.setBounds(25, 75, 100, 25);

        Id_jTextField.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        getContentPane().add(Id_jTextField);
        Id_jTextField.setBounds(145, 75, 50, 25);

        name_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        name_lbl.setForeground(new java.awt.Color(255, 255, 255));
        name_lbl.setText("NAME");
        name_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(name_lbl);
        name_lbl.setBounds(25, 110, 100, 25);

        cnic_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        cnic_lbl.setForeground(new java.awt.Color(255, 255, 255));
        cnic_lbl.setText("CNIC");
        cnic_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(cnic_lbl);
        cnic_lbl.setBounds(25, 145, 100, 25);

        contact_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        contact_lbl.setForeground(new java.awt.Color(255, 255, 255));
        contact_lbl.setText("CONTACT NO");
        contact_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(contact_lbl);
        contact_lbl.setBounds(25, 180, 100, 25);

        address_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        address_lbl.setForeground(new java.awt.Color(255, 255, 255));
        address_lbl.setText("ADDRESS");
        address_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(address_lbl);
        address_lbl.setBounds(25, 215, 100, 25);

        email_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        email_lbl.setForeground(new java.awt.Color(255, 255, 255));
        email_lbl.setText("EMAIL");
        email_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(email_lbl);
        email_lbl.setBounds(25, 251, 100, 25);

        faxno_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        faxno_lbl.setForeground(new java.awt.Color(255, 255, 255));
        faxno_lbl.setText("FAX NO");
        faxno_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(faxno_lbl);
        faxno_lbl.setBounds(429, 110, 100, 25);

        name_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(name_jTextField);
        name_jTextField.setBounds(145, 110, 150, 25);

        address_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(address_jTextField);
        address_jTextField.setBounds(145, 215, 239, 25);

        email_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(email_jTextField);
        email_jTextField.setBounds(140, 250, 239, 25);

        faxno_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(faxno_jTextField);
        faxno_jTextField.setBounds(549, 110, 150, 25);

        company_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        company_lbl.setForeground(new java.awt.Color(255, 255, 255));
        company_lbl.setText("COMPANY");
        company_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(company_lbl);
        company_lbl.setBounds(429, 145, 100, 25);

        product_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        product_lbl.setForeground(new java.awt.Color(255, 255, 255));
        product_lbl.setText("PRODUCT");
        product_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(product_lbl);
        product_lbl.setBounds(429, 180, 100, 25);

        quantity_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        quantity_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                quantity_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(quantity_jTextField);
        quantity_jTextField.setBounds(549, 215, 150, 25);

        quantity_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        quantity_lbl.setForeground(new java.awt.Color(255, 255, 255));
        quantity_lbl.setText("QUANTITY");
        quantity_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(quantity_lbl);
        quantity_lbl.setBounds(429, 215, 100, 25);

        priceperitem_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        priceperitem_lbl.setForeground(new java.awt.Color(255, 255, 255));
        priceperitem_lbl.setText("PRICE PER ITEM");
        priceperitem_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(priceperitem_lbl);
        priceperitem_lbl.setBounds(430, 250, 100, 25);

        priceperitem_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        priceperitem_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                priceperitem_jTextFieldKeyPressed(evt);
            }
        });
        getContentPane().add(priceperitem_jTextField);
        priceperitem_jTextField.setBounds(548, 251, 150, 25);

        totalamount_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        totalamount_lbl.setForeground(new java.awt.Color(255, 255, 255));
        totalamount_lbl.setText("TOTAL AMOUNT");
        totalamount_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(totalamount_lbl);
        totalamount_lbl.setBounds(140, 310, 114, 25);

        totalamount_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        totalamount_jTextField.setDisabledTextColor(new java.awt.Color(204, 0, 0));
        totalamount_jTextField.setEnabled(false);
        totalamount_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalamount_jTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(totalamount_jTextField);
        totalamount_jTextField.setBounds(280, 310, 152, 25);

        try {
            cnic_jFormattedTextField.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-#######-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        cnic_jFormattedTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(cnic_jFormattedTextField);
        cnic_jFormattedTextField.setBounds(145, 145, 150, 25);

        contact_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(contact_jTextField);
        contact_jTextField.setBounds(145, 180, 150, 25);

        loyality_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        loyality_jButton.setText("LOYALITY CARD");
        loyality_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loyality_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(loyality_jButton);
        loyality_jButton.setBounds(561, 300, 129, 25);

        PDF.setText("PDF");
        PDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PDFActionPerformed(evt);
            }
        });
        getContentPane().add(PDF);
        PDF.setBounds(810, 270, 100, 23);

        comapny_jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "HudaBeauty", "Loreal", "Alder AG", "Apcot Crop Sciences", "Agreen Pakistan", "Agrica Chemicals", "Bravo C.S Corporation", "Crop Health Sciences", "Eagle Green Enterprises", "Flower Agro", "Gallant International", "Grapple Limited", "Hanan Manan Pvt.ltd", "Indus AG", "Mux International", "Ornato Chemical", "Paragon Chemicals", "Zarcoo Chemicals", "", "" }));
        comapny_jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comapny_jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(comapny_jComboBox1);
        comapny_jComboBox1.setBounds(550, 150, 150, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(720, 150, 170, 20);

        product_jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Foundation", "Lipstick", "Azoxystrobin ( for crops )", "Boscalid          ( for crops )", "Cyprodrill        (for household)", "Dicloran          (for fungus)", "Fludioxonil      (for Algae)", "Metalaxyt       (for Soil)", "THPI               (for Water)", "Cyfluthrin       (for worms)", "Brifenthrin      (for Bugs)", "Acephate        (for insects)", "Amitraz          (animal's ticks)", "Triflurain        (for cockroaches)", "Mortein          (for mice)", "Mospel           (for Mosquito)  " }));
        product_jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(product_jComboBox1);
        product_jComboBox1.setBounds(550, 180, 150, 20);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(720, 180, 170, 20);

        empback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Forms/Windows-10-Official-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(empback_jLabel);
        empback_jLabel.setBounds(0, 10, 920, 540);

        emp_jMenu.setText("File");

        jMenuItem1.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        jMenuItem1.setText("HOME");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        emp_jMenu.add(jMenuItem1);

        jMenuBar1.add(emp_jMenu);

        setJMenuBar(jMenuBar1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_jButtonActionPerformed
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
           String s1 = Id_jTextField.getText();
           String s2 = name_jTextField.getText();
           String s3 = cnic_jFormattedTextField.getText();
           String s4 = contact_jTextField.getText();
           String s5 = address_jTextField.getText();
           String s6 = email_jTextField.getText();
           String s7 = faxno_jTextField.getText();
           String s8 = jTextField1.getText();
           String s9 = jTextField2.getText();
           String sql = " update CustomerTable set ID='"+ s1 +"',Name='"+ s2 +"',CNIC='"+ s3 +"',ContactNo='"+ s4 +"',Address='"+ s5 +"',Email='"+ s6 +"',faxno='"+ s7+"',company='"+ s8+"',product='"+ 9+"' where ID='"+ s1+"'";
           ps = con.prepareStatement(sql);
           ps.execute();
           JOptionPane.showMessageDialog(null, "UPDATED!!");
         }
         catch (Exception e)
         {
             
         }              
    }//GEN-LAST:event_update_jButtonActionPerformed

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        String name = name_jTextField.getText();
        String cnic = cnic_jFormattedTextField.getText();
        String contact = contact_jTextField.getText();
        String address = address_jTextField.getText();
        String email = email_jTextField.getText();
        String faxno = faxno_jTextField.getText();
        String company;
        company = (String)comapny_jComboBox1.getSelectedItem();
        jTextField1.setText(company);
        
        String product;
        product=(String) product_jComboBox1.getSelectedItem();
        jTextField2.setText(product);
        
        double quantity= Double.parseDouble(quantity_jTextField.getText());
        double priceperitem = Double.parseDouble(priceperitem_jTextField.getText());
        double totalamount = Double.parseDouble(totalamount_jTextField.getText());
        CustomerInfo ei = new CustomerInfo(name, cnic, contact, address, email, faxno,company, product,quantity,priceperitem,totalamount);
        ei.AddCustomer();
        new CustomerInfo().Refresh(emp_jTable);
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_jButtonActionPerformed
        CustomerInfo obj = new CustomerInfo();
        obj.setID(Integer.parseInt(Id_jTextField.getText()));
        int r = JOptionPane.showConfirmDialog(null, "Are you sure to delete?");
        if (r == JOptionPane.YES_OPTION) 
        {
            obj.DeleteCustomer();
            new CustomerInfo().Refresh(emp_jTable);
        }
    }//GEN-LAST:event_delete_jButtonActionPerformed

    private void search_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_jTextFieldActionPerformed
        
    }//GEN-LAST:event_search_jTextFieldActionPerformed

    private void search_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyReleased
         if (search_jTextField.getText().isEmpty())
        {
            new CustomerInfo().Refresh(emp_jTable);
        }
        else
        {
            int id = Integer.parseInt(search_jTextField.getText());
            new CustomerInfo().setID(id);
            new CustomerInfo().SearchCustomer(emp_jTable,search_jTextField.getText());
        }
    }//GEN-LAST:event_search_jTextFieldKeyReleased

    private void emp_jTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emp_jTableMouseClicked
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            int row = emp_jTable.getSelectedRow();
            String clicked = (emp_jTable.getModel().getValueAt(row, 0).toString());
            String sql = "select * from CustomerTable where ID = '"+clicked+"'";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next())
            {
                String add1 = rs.getString("ID");
                Id_jTextField.setText(add1);
                String add2 = rs.getString("Name");
                name_jTextField.setText(add2);
                String add3 = rs.getString("CNIC");
                cnic_jFormattedTextField.setText(add3);
                String add4 = rs.getString("ContactNO");
                contact_jTextField.setText(add4);
                String add5 = rs.getString("Address");
                address_jTextField.setText(add5);
                String add6 = rs.getString("Email");
                email_jTextField.setText(add6);
                String add7 = rs.getString("faxno");
                faxno_jTextField.setText(add7);
                String add8 = rs.getString("company");
                jTextField1.setText(add8);
                String add9 = rs.getString("product");
                jTextField2.setText(add9);
                String add10 = rs.getString("quantity");
                quantity_jTextField.setText(add10);
                String add11 = rs.getString("priceperitem");
                priceperitem_jTextField.setText(add11);
                String add12 = rs.getString("totalamount");
                totalamount_jTextField.setText(add12);
            }
        }
        catch(Exception e)
        {
            JOptionPane.showConfirmDialog(null, e);
        }
    }//GEN-LAST:event_emp_jTableMouseClicked

    private void refresh_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh_jButtonActionPerformed
        new CustomerInfo().Refresh(emp_jTable);
    }//GEN-LAST:event_refresh_jButtonActionPerformed

    private void quantity_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantity_jTextFieldKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_quantity_jTextFieldKeyReleased

    private void priceperitem_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_priceperitem_jTextFieldKeyPressed
        if (priceperitem_jTextField.getText().matches("\\d+"))
        {
            double priceperitem = Double.parseDouble(priceperitem_jTextField.getText());
            double quantity= Double.parseDouble(quantity_jTextField.getText());
            double a = new CustomerInfo().earnings(priceperitem,quantity);
            totalamount_jTextField.setText(String.valueOf(a));
        }
        else
        {
            System.out.println("..");
        }
    }//GEN-LAST:event_priceperitem_jTextFieldKeyPressed

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        name_jTextField.setText(null);
        cnic_jFormattedTextField.setText(null);
        contact_jTextField.setText(null);
        address_jTextField.setText(null);
        email_jTextField.setText(null);
        faxno_jTextField.setText(null);
        jTextField1.setText(null);
      jTextField2.setText(null);
        quantity_jTextField.setText(null);
        priceperitem_jTextField.setText(null);
        totalamount_jTextField.setText(null);
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        HomePageForm hp = new HomePageForm();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void loyality_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loyality_jButtonActionPerformed
        loyalityform sf = new loyalityform();
        sf.setVisible(true);
    }//GEN-LAST:event_loyality_jButtonActionPerformed

    private void PDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PDFActionPerformed
        try
        {
            Document DocumentObj = new Document();

            PdfWriter.getInstance(DocumentObj, new FileOutputStream("CustomerBill.pdf"));

            DocumentObj.open();
            Paragraph pTtile = new Paragraph("MERCELA COSMETICS ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 22, Font.PLAIN, new BaseColor(0, 0, 0)));
            pTtile.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(pTtile);
            Paragraph Ttile = new Paragraph("OWNERS(HIFSA,KAINAT,OMEMA,MARIA) ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.PLAIN, new BaseColor(0, 0, 0)));
            Ttile.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(Ttile);
            Paragraph phonenumber = new Paragraph("PHONE: +123-456-789", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.PLAIN, new BaseColor(0, 0, 0)));
            phonenumber.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(phonenumber);
            
            Paragraph Bank = new Paragraph("MERCELA BANK (Gulshan)", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.PLAIN, new BaseColor(0, 0, 0)));
            Bank.setAlignment(Element.ALIGN_LEFT);
            DocumentObj.add(Bank);
            
            Paragraph accountnumber = new Paragraph("ACCOUNT TITLE: MERCELA COSMETICS DISTRIBUTOR \n ACCOUNT NUMBER: 0001236543219 ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.PLAIN, new BaseColor(0, 0, 0)));
            Bank.setAlignment(Element.ALIGN_LEFT);
            DocumentObj.add(accountnumber);
            
             DocumentObj.add(new Paragraph("Print Date date: " + String.valueOf(new SimpleDateFormat("dd/MM/yyyy").format(new Date()))));
             DocumentObj.add(new Paragraph("Print Time time: " + String.valueOf(new SimpleDateFormat("HH:mm:ss a").format(new Date()))));
             Paragraph lastdate = new Paragraph("RELAXATION..!!!...Pay Before: 30/12/2017", FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0)));
             lastdate.setAlignment(Element.ALIGN_RIGHT);
             DocumentObj.add(lastdate);
             DocumentObj.add(new Paragraph("______________________________________________________________________________"));
             
             PdfPTable PdfPTableObj = new PdfPTable(8);
             PdfPTableObj.setWidthPercentage(100);
             PdfPTableObj.setHorizontalAlignment(Element.ALIGN_LEFT);
             
             PdfPCell PdfPCellObj = new PdfPCell(new Paragraph("CUSTOMER BILL \n", FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.BOLD, BaseColor.BLACK)));
             PdfPCellObj.setColspan(8);
             PdfPCellObj.setPadding(6.0f);
             PdfPCellObj.setVerticalAlignment(Element.ALIGN_CENTER);
             PdfPCellObj.setBackgroundColor(new BaseColor(0, 176, 86));
             
             PdfPTableObj.addCell(PdfPCellObj);
             this.BoldAttributes("Id ", PdfPTableObj);
             this.BoldAttributes("Name: ", PdfPTableObj);
             this.BoldAttributes("cnic", PdfPTableObj);
            this.BoldAttributes("company ", PdfPTableObj);
            this.BoldAttributes("product ", PdfPTableObj);
             this.BoldAttributes("quantity ", PdfPTableObj);
            this.BoldAttributes("priceperitem", PdfPTableObj);
             this.BoldAttributes("totalamount: ", PdfPTableObj);
             PdfPTableObj.addCell(Id_jTextField.getText());
             PdfPTableObj.addCell(name_jTextField.getText());
             PdfPTableObj.addCell(cnic_jFormattedTextField.getText());
             PdfPTableObj.addCell(jTextField1.getText());
             
             
             PdfPTableObj.addCell(jTextField2.getText());
             PdfPTableObj.addCell(quantity_jTextField.getText());
             
             PdfPTableObj.addCell(priceperitem_jTextField.getText());
             PdfPTableObj.addCell(totalamount_jTextField.getText());
            
             DocumentObj.add(PdfPTableObj);
             DocumentObj.close();
            
               String PathOfFile = new File("CustomerBill.pdf").getAbsolutePath(); // Get The Absoulte Path of File
               File PdfFile = new File(PathOfFile);

                if (PdfFile.exists()) {
                    Desktop.getDesktop().open(PdfFile); //Opens up the pdf file automatically
                } else {
                    System.out.println("File does not exits.");
                }
            }
        catch (DocumentException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error : " + e, null, JOptionPane.ERROR_MESSAGE);
        }        
    }                                            
 public void BoldAttributes(String AttributeName, PdfPTable PdfPTableObj)
    {
        Paragraph ParagraphObj = new Paragraph(AttributeName);
        ParagraphObj.getFont().setStyle(Font.BOLD); // Bold krega attribute name ko
        PdfPCell PdfPCellObj = new PdfPCell(ParagraphObj);
        PdfPCellObj.setBackgroundColor(new BaseColor(225, 225, 225)); // Cell colour white 
        PdfPTableObj.addCell(PdfPCellObj);
    
    }//GEN-LAST:event_PDFActionPerformed

    private void comapny_jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comapny_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comapny_jComboBox1ActionPerformed

    private void product_jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_product_jComboBox1ActionPerformed

    private void totalamount_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalamount_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalamount_jTextFieldActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new CustomerForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JTextField Id_jTextField;
    private javax.swing.JButton PDF;
    private javax.swing.JTextField address_jTextField;
    private javax.swing.JLabel address_lbl;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JFormattedTextField cnic_jFormattedTextField;
    private javax.swing.JLabel cnic_lbl;
    private javax.swing.JComboBox<String> comapny_jComboBox1;
    private javax.swing.JLabel company_lbl;
    private javax.swing.JTextField contact_jTextField;
    private javax.swing.JLabel contact_lbl;
    private javax.swing.JButton delete_jButton;
    private javax.swing.JTextField email_jTextField;
    private javax.swing.JLabel email_lbl;
    private javax.swing.JMenu emp_jMenu;
    private javax.swing.JTable emp_jTable;
    private javax.swing.JLabel empback_jLabel;
    private javax.swing.JTextField faxno_jTextField;
    private javax.swing.JLabel faxno_lbl;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton loyality_jButton;
    private javax.swing.JTextField name_jTextField;
    private javax.swing.JLabel name_lbl;
    private javax.swing.JTextField priceperitem_jTextField;
    private javax.swing.JLabel priceperitem_lbl;
    private javax.swing.JComboBox<String> product_jComboBox1;
    private javax.swing.JLabel product_lbl;
    private javax.swing.JTextField quantity_jTextField;
    private javax.swing.JLabel quantity_lbl;
    private javax.swing.JButton refresh_jButton;
    private javax.swing.JTextField search_jTextField;
    private javax.swing.JLabel search_lbl;
    private javax.swing.JLabel title_jLabel;
    private javax.swing.JTextField totalamount_jTextField;
    private javax.swing.JLabel totalamount_lbl;
    private javax.swing.JButton update_jButton;
    // End of variables declaration//GEN-END:variables
}
