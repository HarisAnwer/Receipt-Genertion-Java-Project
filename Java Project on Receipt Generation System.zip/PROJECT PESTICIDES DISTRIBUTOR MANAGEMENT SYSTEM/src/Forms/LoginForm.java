
package Forms;

import Classes.DatabaseConnection;
import javax.swing.JOptionPane;

public class LoginForm extends javax.swing.JFrame 
{

    public LoginForm()
    {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logintitle_jLabel = new javax.swing.JLabel();
        password_jLabel = new javax.swing.JLabel();
        username_jLabel = new javax.swing.JLabel();
        username_jTextField = new javax.swing.JTextField();
        login_jPasswordField = new javax.swing.JPasswordField();
        clear_jButton = new javax.swing.JButton();
        login_jButton = new javax.swing.JButton();
        back_lbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MERCELA PESTICIDES DISTRIBUTOR MANAGEMENT SYSTEM");
        setBounds(new java.awt.Rectangle(759, 461, 461, 461));
        setMaximumSize(new java.awt.Dimension(759, 461));
        setMinimumSize(new java.awt.Dimension(759, 461));
        setPreferredSize(new java.awt.Dimension(759, 461));
        setResizable(false);
        setSize(new java.awt.Dimension(759, 461));
        getContentPane().setLayout(null);

        logintitle_jLabel.setFont(new java.awt.Font("Algerian", 0, 48)); // NOI18N
        logintitle_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        logintitle_jLabel.setText("COSMETICS DISTRIBUTOR ");
        getContentPane().add(logintitle_jLabel);
        logintitle_jLabel.setBounds(80, 60, 580, 60);

        password_jLabel.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        password_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        password_jLabel.setText("PASSWORD");
        getContentPane().add(password_jLabel);
        password_jLabel.setBounds(30, 330, 100, 25);

        username_jLabel.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        username_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        username_jLabel.setText("USER NAME");
        getContentPane().add(username_jLabel);
        username_jLabel.setBounds(30, 290, 100, 25);

        username_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(username_jTextField);
        username_jTextField.setBounds(130, 290, 240, 25);

        login_jPasswordField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(login_jPasswordField);
        login_jPasswordField.setBounds(130, 330, 240, 25);

        clear_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        clear_jButton.setText("CLEAR");
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(260, 370, 110, 25);

        login_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        login_jButton.setText("LOGIN");
        login_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        login_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(login_jButton);
        login_jButton.setBounds(130, 370, 102, 25);

        back_lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Forms/loginback.jpg"))); // NOI18N
        getContentPane().add(back_lbl);
        back_lbl.setBounds(0, 20, 760, 440);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        login_jPasswordField.setText(null);
        username_jTextField.setText(null);
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void login_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_jButtonActionPerformed
         DatabaseConnection cd = new DatabaseConnection();
         String pass = String.valueOf(login_jPasswordField.getPassword());
         if (cd.matchPasswordVerification(username_jTextField.getText(), pass))
         {
            JOptionPane.showMessageDialog(null, "Success!");
            HomePageForm h = new HomePageForm();
            h.setVisible(true);
            dispose();
            
         }
         else
         {
             JOptionPane.showMessageDialog(null, "Failed!!");
         }
    }//GEN-LAST:event_login_jButtonActionPerformed

    public static void main(String args[]) 
    {
        
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new LoginForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel back_lbl;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JButton login_jButton;
    private javax.swing.JPasswordField login_jPasswordField;
    private javax.swing.JLabel logintitle_jLabel;
    private javax.swing.JLabel password_jLabel;
    private javax.swing.JLabel username_jLabel;
    private javax.swing.JTextField username_jTextField;
    // End of variables declaration//GEN-END:variables
}
