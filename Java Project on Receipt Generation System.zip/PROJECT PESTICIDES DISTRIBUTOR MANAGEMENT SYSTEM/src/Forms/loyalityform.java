package Forms;
import Classes.Loyalitycard;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
public class loyalityform extends javax.swing.JFrame
{
    public loyalityform() 
    {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        name_lbl = new javax.swing.JLabel();
        name_jTextField = new javax.swing.JTextField();
        cnic_lbl = new javax.swing.JLabel();
        exp_lbl = new javax.swing.JLabel();
        exp_jTextField = new javax.swing.JTextField();
        mfg_lbl = new javax.swing.JLabel();
        mfg_jTextField = new javax.swing.JTextField();
        generate_jButton = new javax.swing.JButton();
        ADD = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        totalamount_jTextField = new javax.swing.JTextField();
        cnic_jTextField = new javax.swing.JFormattedTextField();
        salback_jLabel = new javax.swing.JLabel();
        loyality_jMenuBar = new javax.swing.JMenuBar();
        sal_jMenu = new javax.swing.JMenu();
        emp_jMenuItem = new javax.swing.JMenuItem();
        HOME = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBounds(new java.awt.Rectangle(371, 433, 433, 433));
        setMaximumSize(new java.awt.Dimension(371, 459));
        setMinimumSize(new java.awt.Dimension(371, 459));
        setResizable(false);
        setSize(new java.awt.Dimension(371, 459));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Californian FB", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("LOYALITY CARD");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(70, 20, 200, 40);

        name_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        name_lbl.setForeground(new java.awt.Color(255, 255, 255));
        name_lbl.setText("NAME");
        name_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(name_lbl);
        name_lbl.setBounds(50, 110, 100, 25);

        name_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        getContentPane().add(name_jTextField);
        name_jTextField.setBounds(168, 110, 150, 25);

        cnic_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        cnic_lbl.setForeground(new java.awt.Color(255, 255, 255));
        cnic_lbl.setText("CNIC");
        cnic_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(cnic_lbl);
        cnic_lbl.setBounds(50, 141, 100, 25);

        exp_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        exp_lbl.setForeground(new java.awt.Color(255, 255, 255));
        exp_lbl.setText("E.X.P YEAR");
        exp_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(exp_lbl);
        exp_lbl.setBounds(50, 213, 100, 25);

        exp_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        exp_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                exp_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(exp_jTextField);
        exp_jTextField.setBounds(168, 213, 150, 25);

        mfg_lbl.setFont(new java.awt.Font("Calibri Light", 1, 12)); // NOI18N
        mfg_lbl.setForeground(new java.awt.Color(255, 255, 255));
        mfg_lbl.setText("M.F.G YEAR");
        mfg_lbl.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(mfg_lbl);
        mfg_lbl.setBounds(50, 177, 100, 25);

        mfg_jTextField.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        mfg_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                mfg_jTextFieldKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                mfg_jTextFieldKeyTyped(evt);
            }
        });
        getContentPane().add(mfg_jTextField);
        mfg_jTextField.setBounds(168, 177, 150, 25);

        generate_jButton.setFont(new java.awt.Font("Californian FB", 1, 12)); // NOI18N
        generate_jButton.setText("PDF");
        generate_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generate_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(generate_jButton);
        generate_jButton.setBounds(230, 310, 90, 23);

        ADD.setText("ADD");
        ADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDActionPerformed(evt);
            }
        });
        getContentPane().add(ADD);
        ADD.setBounds(150, 310, 70, 23);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PRICE");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 250, 100, 20);
        getContentPane().add(totalamount_jTextField);
        totalamount_jTextField.setBounds(170, 250, 150, 20);

        try {
            cnic_jTextField.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-########-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        getContentPane().add(cnic_jTextField);
        cnic_jTextField.setBounds(170, 150, 150, 20);

        salback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Forms/Windows-10-Official-Wallpaper.jpg"))); // NOI18N
        getContentPane().add(salback_jLabel);
        salback_jLabel.setBounds(-150, 0, 520, 440);

        sal_jMenu.setText("File");

        emp_jMenuItem.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        emp_jMenuItem.setText("Customer Information");
        emp_jMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_jMenuItemActionPerformed(evt);
            }
        });
        sal_jMenu.add(emp_jMenuItem);

        HOME.setFont(new java.awt.Font("Californian FB", 1, 14)); // NOI18N
        HOME.setText("Home");
        HOME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HOMEActionPerformed(evt);
            }
        });
        sal_jMenu.add(HOME);

        loyality_jMenuBar.add(sal_jMenu);

        setJMenuBar(loyality_jMenuBar);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exp_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_exp_jTextFieldKeyReleased
       if (exp_jTextField.getText().matches("\\d+")) { 
            System.out.println("Number");
            
        }
        else {
            System.out.println("..");
        }       
    }//GEN-LAST:event_exp_jTextFieldKeyReleased

    private void mfg_jTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mfg_jTextFieldKeyTyped
        
    }//GEN-LAST:event_mfg_jTextFieldKeyTyped

    private void mfg_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mfg_jTextFieldKeyReleased
        // D INTEGER KO SHOW KR RAHA HAI
        if (mfg_jTextField.getText().matches("\\d+")) { 
            System.out.println("Number");
            
        }
        else {
            System.out.println("..");
        }
    }//GEN-LAST:event_mfg_jTextFieldKeyReleased

    private void generate_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generate_jButtonActionPerformed
 try
        {
            Document DocumentObj = new Document();

            PdfWriter.getInstance(DocumentObj, new FileOutputStream("LoyalityCard.pdf"));

            DocumentObj.open();
            Paragraph pTtile = new Paragraph("MERCELA PESTICIDES ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 22, Font.PLAIN, new BaseColor(255, 0, 255)));
            pTtile.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(pTtile);
            Paragraph Ttile = new Paragraph("OWNERS(HIFSA,KAINAT,OMEMA,MARIA) ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.PLAIN, new BaseColor(0, 0, 255)));
            Ttile.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(Ttile);
            Paragraph phonenumber = new Paragraph("PHONE: +123-456-789", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.PLAIN, new BaseColor(0, 176, 86)));
            phonenumber.setAlignment(Element.ALIGN_CENTER);
            DocumentObj.add(phonenumber);
            
            Paragraph Bank = new Paragraph("MERCELA BANK (Gulshan)", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.PLAIN, new BaseColor(0, 0, 0)));
            Bank.setAlignment(Element.ALIGN_LEFT);
            DocumentObj.add(Bank);
            
            Paragraph accountnumber = new Paragraph("ACCOUNT TITLE: MERCELA PESTICIDE DISTRIBUTOR \n ACCOUNT NUMBER: 0001236543219 ", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.PLAIN, new BaseColor(0, 0, 0)));
            Bank.setAlignment(Element.ALIGN_LEFT);
            DocumentObj.add(accountnumber);
            
             DocumentObj.add(new Paragraph("Print Date date: " + String.valueOf(new SimpleDateFormat("dd/MM/yyyy").format(new Date()))));
             DocumentObj.add(new Paragraph("Print Time time: " + String.valueOf(new SimpleDateFormat("HH:mm:ss a").format(new Date()))));
             Paragraph lastdate = new Paragraph("Thanks For Membership", FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0)));
             lastdate.setAlignment(Element.ALIGN_RIGHT);
             DocumentObj.add(lastdate);
             DocumentObj.add(new Paragraph("______________________________________________________________________________"));
             
             PdfPTable PdfPTableObj = new PdfPTable(5);
             PdfPTableObj.setWidthPercentage(100);
             PdfPTableObj.setHorizontalAlignment(Element.ALIGN_LEFT);
             
             PdfPCell PdfPCellObj = new PdfPCell(new Paragraph("CUSTOMER LOYALITY CARD \n", FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.BOLD, BaseColor.BLACK)));
             PdfPCellObj.setColspan(5);
             PdfPCellObj.setPadding(6.0f);
             PdfPCellObj.setVerticalAlignment(Element.ALIGN_CENTER);
             PdfPCellObj.setBackgroundColor(new BaseColor(255,255,0));
             
             PdfPTableObj.addCell(PdfPCellObj);
             
             this.BoldAttributes("NAME: ", PdfPTableObj);
             this.BoldAttributes("CNIC", PdfPTableObj);
            
             this.BoldAttributes("ISSUING DATE ", PdfPTableObj);
            this.BoldAttributes("E.X.P DATE", PdfPTableObj);
            this.BoldAttributes("PRICE", PdfPTableObj);
             
             
             PdfPTableObj.addCell(name_jTextField.getText());
             PdfPTableObj.addCell(cnic_jTextField.getText());
             
             PdfPTableObj.addCell(mfg_jTextField.getText());
             
             PdfPTableObj.addCell(exp_jTextField.getText());
             PdfPTableObj.addCell(totalamount_jTextField.getText());
             
            
             DocumentObj.add(PdfPTableObj);
             DocumentObj.close();
            
               String PathOfFile = new File("LoyalityCard.pdf").getAbsolutePath(); // Get The Absoulte Path of File
               File PdfFile = new File(PathOfFile);

                if (PdfFile.exists()) {
                    Desktop.getDesktop().open(PdfFile); //Opens up the pdf file automatically
                } else {
                    System.out.println("File does not exits.");
                }
            }
        catch (DocumentException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error : " + e, null, JOptionPane.ERROR_MESSAGE);
        }                
    }//GEN-LAST:event_generate_jButtonActionPerformed
public void BoldAttributes(String AttributeName, PdfPTable PdfPTableObj)
    {
        Paragraph ParagraphObj = new Paragraph(AttributeName);
        ParagraphObj.getFont().setStyle(Font.BOLD); // Bold krega attribute name ko
        PdfPCell PdfPCellObj = new PdfPCell(ParagraphObj);
        PdfPCellObj.setBackgroundColor(new BaseColor(225, 225, 225)); // Cell colour white 
        PdfPTableObj.addCell(PdfPCellObj);
    
    }                                   

    private void emp_jMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_jMenuItemActionPerformed
        CustomerForm ef = new CustomerForm();
        ef.setVisible(true);
        dispose();
    }//GEN-LAST:event_emp_jMenuItemActionPerformed

    private void HOMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HOMEActionPerformed
        HomePageForm hp = new HomePageForm();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_HOMEActionPerformed

    private void ADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDActionPerformed
String name = name_jTextField.getText();
        String cnic = cnic_jTextField.getText();
       double price=Double.parseDouble(totalamount_jTextField.getText());
       
        
        double mfg= Double.parseDouble(mfg_jTextField.getText());
        double exp = Double.parseDouble(exp_jTextField.getText());
       
        Loyalitycard ej = new Loyalitycard(name, cnic,mfg,exp,price);
        ej.AddCustomer();
                
    }//GEN-LAST:event_ADDActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new loyalityform().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADD;
    private javax.swing.JMenuItem HOME;
    private javax.swing.JFormattedTextField cnic_jTextField;
    private javax.swing.JLabel cnic_lbl;
    private javax.swing.JMenuItem emp_jMenuItem;
    private javax.swing.JTextField exp_jTextField;
    private javax.swing.JLabel exp_lbl;
    private javax.swing.JButton generate_jButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar loyality_jMenuBar;
    private javax.swing.JTextField mfg_jTextField;
    private javax.swing.JLabel mfg_lbl;
    private javax.swing.JTextField name_jTextField;
    private javax.swing.JLabel name_lbl;
    private javax.swing.JMenu sal_jMenu;
    private javax.swing.JLabel salback_jLabel;
    private javax.swing.JTextField totalamount_jTextField;
    // End of variables declaration//GEN-END:variables
}
