package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection 
{
    public Connection setConnection() 
    {
        Connection Con = null;
        try
        {
            /* Loading the driver */
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            
            /* Establishing the connection */
            Con = DriverManager.getConnection("jdbc:ucanaccess://managementsystem.accdb"); 
            
        }
        catch (SQLException | ClassNotFoundException e)
        {
            
            /* Error message */
            System.out.println("Connection Failed");
        }
        return Con; // returns the connection
    }
    
    public boolean matchPasswordVerification(String user, String pass)
    {
        boolean successful = false;
        try {
            Connection con = setConnection();  
            Statement st = con.createStatement();
            String sql = "SELECT * FROM PasswordVerification where username = '"+ user +"'";
            ResultSet rs = st.executeQuery(sql);
            if (rs.next())
            {
              String userName = rs.getString("UserName");
              String password = rs.getString("Password");
              if(user.equals(userName) && pass.equals(password))
                  successful = true;
              else
                  successful = false;
            }
            con.close();
        }
        catch(Exception sqlEx)
        {
                    System.out.println(sqlEx);
        }     
        return successful;
    }
}

