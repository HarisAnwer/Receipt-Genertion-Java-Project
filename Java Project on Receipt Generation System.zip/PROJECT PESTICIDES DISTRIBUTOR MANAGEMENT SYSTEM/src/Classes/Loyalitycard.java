
package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Loyalitycard extends CustomerInfo
{
     Connection con = new DatabaseConnection().setConnection();
   
    private double mfg;
    private double exp;
    private double price;

    public Loyalitycard(String Name, String CNIC, double mfg, double exp, double price) {
       
        this.mfg= mfg;
        this.exp = exp;
        this.price= price;
    }
    
    public void setMfg(double mfg) 
    {
        this.mfg= mfg;
    }

    public void setExp(double exp) 
    {
        this.exp=exp;
    }

    public void setPrice(double Price) {
        this.price = price;
    }
    
    public double getmfg()
    {
        return mfg;
    }

    public double getExp() 
    {
        return exp;
    }

    public double getprice() {
        return price;
    }

    @Override
    public String toString() {
        return "CustomerBill{" + "mfg=" + mfg + ", exp=" + exp + ", price=" + price + '}';
    }

    public Loyalitycard() {
    }
    
    
    
        public void AddCustomer()
    {
        try
        {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String sql = "insert into LoyalityTable(Name,CNIC,mfg,exp,totalamount) values (?,?,?,?,?)";
        ps = con.prepareStatement(sql);
        ps.setString(1, super.getName());
        ps.setString(2, super.getCNIC());
        ps.setDouble(3, mfg);
        ps.setDouble(4, exp);
        ps.setDouble(5,price);
        JOptionPane.showMessageDialog(null, "Added!!");
        ps.execute();
        ps.close();
        con.close();
        
        }
        catch(SQLException e)
        {
            JOptionPane.showConfirmDialog(null, e); 
        }
    }
    
   


}
