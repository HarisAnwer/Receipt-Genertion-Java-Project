package Classes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class CustomerInfo
{
    Connection con = new DatabaseConnection().setConnection();
    
    private int ID;
    private String Name;
    private String CNIC;
    private String ContactNo;
    private String Address;
    private String Email;
    private String faxno;
    private String company;
    private String product;
    private double quantity;
    private double priceperitem;
    private double totalamount;    
    
    public CustomerInfo(String Name, String CNIC, String ContactNo, String Address, String Email, String faxno, String company, String product,double quantity,double priceperitem, double totalamount)
    {
        
        this.Name = Name;
        this.CNIC = CNIC;
        this.ContactNo = ContactNo;
        this.Address = Address;
        this.Email = Email;
        this.faxno= faxno;
        this.company = company;
        this.product = product;
        this.quantity = quantity;
        this.priceperitem = priceperitem;
        this.totalamount = totalamount;
    }    
    public CustomerInfo() 
    {
        
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public void setContactNo(String ContactNo) {
        this.ContactNo = ContactNo;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setFaxno(String faxno) {
        this.faxno = faxno;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setProduct(String product) {
        this.product= product;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getCNIC() {
        return CNIC;
    }

    public String getContactNo() {
        return ContactNo;
    }

    public String getAddress() {
        return Address;
    }

    public String getEmail() {
        return Email;
    }

    public String getFaxno() {
        return faxno;
    }

    public String getCompany() {
        return company;
    }

    public String getProduct() {
        return product;
    }
    
     public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public void setPriceperitem(double priceperitem) {
        this.priceperitem = priceperitem;
    }

    public void setTotalamount(double totalamount) {
        this.totalamount = totalamount;
    }

    public double getQuantity() {
        return quantity;
    }

    public double getPriceperitem() {
        return priceperitem;
    }

    public double getTotalamount() {
        return priceperitem*quantity;
    }

    @Override
    public String toString() {
        return "CustomerInfo{" + "Name=" + Name + ", CNIC=" + CNIC + ", ContactNo=" + ContactNo + ", Address=" + Address + ", Email=" + Email + ",  faxno=" + faxno + ", company=" + company + ", product=" + product + ", quantity=" + quantity+ ", priceperitem=" + priceperitem+ ", totalamount=" + totalamount + '}';
    }
    
     public void AddCustomer()
    {
        try
        {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String sql = "insert into CustomerTable(Name,CNIC,ContactNo,Address,Email,faxno,company,product,quantity,priceperitem,totalamount) values (?,?,?,?,?,?,?,?,?,?,?)";
        ps = con.prepareStatement(sql);
        ps.setString(1, Name);
        ps.setString(2, CNIC);
        ps.setString(3, ContactNo);
        ps.setString(4, Address);
        ps.setString(5, Email);
        ps.setString(6, faxno);
        ps.setString(7, company);
        ps.setString(8, product);
        ps.setDouble(9, quantity);
        ps.setDouble(10, priceperitem);
        ps.setDouble(11, totalamount);
        JOptionPane.showMessageDialog(null, "Added!!");
        ps.execute();
        ps.close();
        con.close();
        
        }
        
        catch(SQLException e)
        {
            JOptionPane.showConfirmDialog(null, e); 
        }
    }
    
     public void DeleteCustomer()
    {
        Statement ps = null;
        
        try 
        {
            ps = con.createStatement();
            String s = "delete from CustomerTable where ID='"+ID+"'";
            ps.execute(s);
            ps.close();
            con.close();
        }
        catch (SQLException e)
        {
            JOptionPane.showConfirmDialog(null, e); 
        }
    }
    
     public void Refresh(JTable table)
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String s = "select * from CustomerTable";
            ps = con.prepareStatement(s);
            rs = ps.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
            ps.close();
            rs.close();
            con.close();
        }
        catch (SQLException e) 
        {
            JOptionPane.showConfirmDialog(null, e); 
        }
    }
     
     public void SearchCustomer(JTable table,String id)
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try
        {
            String s = "select * from CustomerTable where ID=?";
            ps = con.prepareStatement(s);
            ps.setString(1,id);
            rs = ps.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
            ps.close();
            rs.close();
            con.close();
        }
        catch (SQLException e) 
        {
            JOptionPane.showConfirmDialog(null, e); 
        }
    }
   public double earnings( double  priceperitem , double quantity)
    {
        
             double ab=priceperitem+(priceperitem*0.16);
        double a=ab*quantity;
        
        return a;
    }
}
